using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class SetPlayerName : MonoBehaviour
{
    public TextMeshProUGUI user_name;       //Platsen d�r det kommer visas i Runtime UI. 
    public TMP_InputField user_inputfield;  //"Inputf�ltet d�r spelaren skrivit sitt namn. 

    public void setName()
    {
        user_name.text = user_inputfield.text; //S�tt spelarens namn till det hen skrivit. 

    }
}
