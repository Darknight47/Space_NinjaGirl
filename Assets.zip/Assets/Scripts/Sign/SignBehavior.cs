using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SignBehavior : MonoBehaviour
{

    public GameObject Textobject; //G�r att skylten kan pekas till sitt textobjekt. 


    private void OnTriggerEnter2D(Collider2D collision) //om spelaren g�r in i collidern, aktivera textobjektet. 
    {
        if (collision.CompareTag("Player")) 
        {
            Textobject.SetActive(true);
        }
    }


    private void OnTriggerExit2D(Collider2D collision) //Om spelaren l�mnar collidern, deaktivera textobjektet. 
    {
        if (collision.CompareTag("Player"))
        {
            Textobject.SetActive(false);
        }
    }

}
