﻿namespace NinjaGirl
{
    public interface IDamageable
    {
        int Health { get; set; }

        void Damage();
    }

}
