﻿using UnityEngine;


namespace NinjaGirl
{
    public class Ladder : MonoBehaviour
    {

        private Movement player;

        private void Start()
        {
            player = GameObject.FindWithTag("Player").GetComponent<Movement>();
        }

        void OnTriggerEnter2D(Collider2D andraObjekt)
        {
            if(andraObjekt.tag == "Player")
            {
                player.climb = true;
                player.onLadder = true;
            }
        }

        void OnTriggerExit2D(Collider2D andraObjekt)
        {
            if(andraObjekt.tag == "Player")
            {
                player.climb = false;
                player.onLadder = false;
            }
        }


    }
}

